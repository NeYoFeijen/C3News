TaskFolder:

Issues/Bugs zoeken: Thierry (kan je hieronder neerzetten)
voorbeeld bug, dit is er aan de hand op die pagina (andere voorbeelden kijk onderstaand)


MenuBalk fixen: Alex/Ne-Yo?
Pagina waar je op zit moet de 'home' texture krijgen (zodat het duidelijker is dat je op die pagina bent)

Carousel (news) fixen: Ne-Yo 
Arrows fixen van de Carousel in de newsPage (fullscreen) - Fixed
Wanneer de nav smaller wordt (bijvoorbeeld wanneer je ipad vieuw pakt rechtop) verdwijnen de arrows om de carousel te draaien.


documentatie checklist:
???????????????????????????????????????
backlog etc.

Definitiestudie

Functioneel en Technische ontwerp (D2)
