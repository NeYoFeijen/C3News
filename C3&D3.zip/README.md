Bootstrap C3 opdracht

dit is onze C3 bootstrap pagina het thema is halloween
